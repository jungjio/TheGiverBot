#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 17:00:37 2017

@author: joshjung
"""
import re
import webbrowser
import requests
import sys
import cookielib
import Tkinter as tk
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
from collections import OrderedDict

utf1 = '%E2%9C%93' #how to send request to atc
commit1 = 'add to cart'
_UTMC = '74692624'
_GAT = '1'
__UTMT = '1'
__UTMA= '74692624.1540672019.1492808721.1493098767.1493149663.16'
__UTMZ='74692624.1492808721.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)'
SUPREMECART = 'http:www.supremenewyork.com/shop/cart'
SITEKEY = "6LeWwRkUAAAAAOBsau7KpuC9AV-6J8mhw4AjC3Xz"
CAPTANSWER ='03AIezHSZ6y7GJ2AYcb1z031JlZOwNb7JEzqMdP5m6rF7Ty3ZjB96g8T0eqtOqeUxCkmVjbGE2xkKJ5IFqrEh28RXT7KWpeoK4ywKcAtosSqL2fcCBOBbcMiG-TGERpoNxZ-2nTFzJrvRclQWyRkocQqJv5V-SDEj00kk4--yJmk2UMw4K2TchZqF01mly0-FV91dFKGlis4QUwWZEM3xZZ42hPM3WIbbEyrVHj7GLgMRhWhsVdaOq4Ro_mEZ-hdkdh7MSLlWQlBqlqmoZ2o_qSWRWDneqSnaPbfD8DUPIWcygWmqg13d3nszG7TQvlplzLsJWFt_sQis1WHo8OEsVgw6DmvXI99uADKnLbRYQ61e5S1JPxxOIV0eLfPHPLFSmL510O-qRTRjwvlEeWw2qsV_QodxLxIIRI7dRNgFkdmFJ_2_NBywKu3A'
SUPREME = 'http://www.supremenewyork.com'
SUPREMEJACKETS = 'http://www.supremenewyork.com/shop/all/jackets'
SUPREMESHIRTS = 'http://www.supremenewyork.com/shop/all/shirts'
SUPREMESWEATERS = 'http://www.supremenewyork.com/shop/all/tops_sweaters'
SUPREMESWEATSHIRT = 'http://www.supremenewyork.com/shop/all/sweatshirts'
SUPREMEPANTS = 'http://www.supremenewyork.com/shop/all/pants'
SUPREMESHORTS= 'http://www.supremenewyork.com/shop/all/shorts'
SUPREMEHATS = 'http://www.supremenewyork.com/shop/all/hats'
SUPREMEACCESSORIES = 'http://www.supremenewyork.com/shop/all/accessories'
SUPREMETSHIRTS = 'http://www.supremenewyork.com/shop/all/t-shirts'
SUPREMECHECKOUT = 'https://www.supremenewyork.com/checkout.js'
SUPREMESHOES = 'http://www.supremenewyork.com/shop/all/shoes'





def Categories(wyw): #category
    print "faggot"
    if "jackets" in wyw:
        supreme = SUPREMEJACKETS
        return supreme
    if "shirts" in wyw:
        supreme = SUPREMESHIRTS
        return supreme
    if "tshirts" in wyw:
        supreme = SUPREMETSHIRTS
        return supreme
    if "sweaters" in wyw:
        supreme = SUPREMESWEATERS
        return supreme
    if "sweatshirts" in wyw:
        supreme = SUPREMESWEATSHIRT
        return supreme
    if  "pants" in wyw:
        supreme = SUPREMEPANTS
        return supreme
    if "shorts" in wyw:
        supreme = SUPREMESHORTS
        return supreme
    if "hats" in wyw:
        supreme = SUPREMEHATS
        return supreme
    if "accessories" in wyw:
        print "faggot"
        supreme = SUPREMEACCESSORIES
        return supreme
    if  "shoes" in wyw:
        supreme = SUPREMESHOES
        return supreme

def keywordhunter(cop, keyword, colorwave): #finds keyword and color returns the final link
    final1 = str("")
    final2 = str("") #you need this for keyword searcher
    #link = cop.find_all("article")

#, {'class': 'name-link'}
    for links in cop.find_all('a'):
        if keyword in links.text:
            final1 = links['href']
            final3 = cop.find_all("a", href=re.compile(final1))
            if colorwave in str(final3):
                return SUPREME + final1



    # for links in cop.find_all("h1"): # what the thingy
    #     if keyword in links.text:
    #         final1 = final1 + str(links)
    #         print final1['href']
    # for links in cop.find_all("p"): # colour
    #     if colorwave in .splitlines()links.text:
    #         final2 = final2 + str(links)
    #         print final2['href']


    final1 = re.sub('<h1><a class="name-link" href="', " ", final1)
    final1 = re.sub('</a></h1>', " ", final1)
    final1 = re.sub(keyword, " ", final1)
    final1 = re.sub('>', " ", final1)
    final1 = re.sub('"', " ", final1)

    final2 = re.sub('<p><a class="name-link" href="', " ", final2)
    final2 = re.sub('</a></p>', " ", final2)
    final2 = re.sub('>', " ", final2)
    final2 = re.sub('"', " ", final2)
    fin1 = final1.split()
    fin2 = final2.split()


    fin3 = set(fin1).intersection(fin2)
    sfin3 = repr(fin3)
    sfin3 = re.sub('set', "", sfin3)
    sfin3 = sfin3.replace("[", "")
    sfin3 = sfin3.replace("]", "")
    sfin3 = sfin3.replace(")", "")
    sfin3 = sfin3.replace("(", "")
    sfin3 = sfin3.replace("'", "")
    return SUPREME + sfin3
def get_session_id(csrftoken): #look for session id
        csrf = "csrf-token"
        for link in csrftoken.find_all("meta"): # what the thingyl #change to meta content
             if csrf in str(link): #grab csrf token lmao
                 gotcha = str(link)
        csrf = gotcha
        gotcha = re.sub('<meta content="', "", gotcha)
        gotcha = re.sub('" name="csrf-token"/>', "", gotcha)

        return gotcha

def Sizefinder(link, size): #simplified
    final1 = ""
    captcha_page = requests.get(link)
    soup = BeautifulSoup(captcha_page.content)
    if size in "":
        return soup.find("input",{"name":"size"})["value"]
    else:
        for action in soup.find_all('select'):
            for actions in action.find_all('option'):
                if size in actions:
                    return actions['value']


def Stylecode(link): #style code
    final1 = ""
    swag = ""
    captcha_page = requests.get(link)
    soup = BeautifulSoup(captcha_page.content)
    return soup.find("input",{"name":"style"})["value"]


def atclink1(link,size5, style1, size): #final link to add to cart and simplified
    atclink = requests.get(link)
    swag = ""
    soup = BeautifulSoup(atclink.content, "html.parser")
    for action in soup.find_all('form'):
        swag = action['action']
    return SUPREME + swag
def quit():
    global root
    root.quit()
def change_dropdown(*args):
        print( tkvar.get() )
def cop():
    category = var.get()
    if category in "jacketsshirtstshirtssweaterssweatshirtsaccessories":
        size = var1.get()
    if category in "shoes":
        size = var2.get()
    if category in "pantsshorts":
        size = var3.get()
    creditcardtype = var4.get()
    keyword = keyword1.get()
    colorwave = colorwave1.get()
    fullname = fullname1.get()
    email = email1.get()
    tele = tele1.get()
    address = address2.get()
    adres1 = (SecAddress.get())
    address1 = str(adres1)
    zipcode = zipcode1.get()
    city = city1.get()
    state = state1.get()
    creditcard = creditcard1.get()
    creditmonth = creditmonth1.get()
    credityear = credityear1.get()
    creditsec = creditsec1.get()

    print category
    print creditcardtype
    print keyword
    print colorwave
    print fullname
    print email
    print tele
    print address
    print adres1
    print address1
    print zipcode
    print city
    print state
    print creditcard
    print creditmonth
    print credityear
    print creditsec


    fullname = fullname.replace(" ","+" )
    address = address.replace(" ","+" )
    address1 = address1.replace(" ","+" )
    city = city.replace(" ","+" )
    state = state.replace(" ","+" )
    email = email.replace("@","%40")
    addy = fullname + '%7C' + address + '%7C' + address1 + '%7C' + city + '%7C' + state + '%7C' + zipcode + '%7C' + 'USA' + '%7C' + email + '%7C' + tele

    print 1
    #Joshua%7C123+lane%7C%7CMA%7CBoston%7C02215%7CUSA%7CJio%40yahoo.com%7C3106166650
    #

    #Joshua+Jung%7C2+Buswell+St%7CApt+4%7CBoston%7CMA%7C02215%7CUSA%7Cjungjio%40yahoo.com%7C3106166650

    #Joshua+jung%7C123+Fuck+off%7CApt+F+u%7CMA%7CBoston%7C02215%7CUSA%7Cjungjio%40yahoo.com%7C3106166650'

    j = category
    j = str(category)
    supreme = Categories((j))
    supreme = requests.get(supreme)
    cop = BeautifulSoup(supreme.content, "html.parser")
    link = cop.find_all("article")
    print '123'
    target =  keywordhunter(cop,keyword, colorwave) #look for things link
    print target
    print '234'
    size1 = Sizefinder(target,size) #look for things size finder
    style1 = Stylecode(target)
    destroy= requests.Session()
    destroyer = destroy.get(target) #starts the session
    csrftoken = BeautifulSoup(destroyer.content, "html.parser") #what he said ^
    token = get_session_id(csrftoken)
    destroy.cookies.get_dict()

    atclink = atclink1(target, size1,style1, size)
    {}
    headers1 = {'User-Agent' : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"}
    data1 = {'utf8': '%E2%9C%93',
               'style': style1, 'size': size1,
               'commit':commit1,
               }
    d1 = OrderedDict([('utf8', '%E2%9C%93'),
                    ('style', style1),
                    ('size', size1),
                    ('commit',commit1)])

    #X-CSRF-Token': token
    payload = {'type': 'submit', 'name': 'commit', 'value': 'add to cart', 'X-CSRF-Token': token}

    d = OrderedDict([('utf8', utf1),
    ('authenticity_token', token),
    ('order[billing_name', fullname),
    ('order[email]', email),
    ('order[tel]', tele),
    ('order[billing_address]', address),
    ('order[billing_address_2]', address1),
    ('order[billing_zip]', zipcode),
    ('order[billing_city]', city,),
    ('order[billing_state]', state),
    ('order[billing_country]', 'USA'),
    ('same_as_billing_address','1'),
    ('store_credit_id' , ''), #this is blank
    ('store_address', '1',),    #this is 1
    ('credit_card[type]',creditcardtype),
    ('credit_card[nlb]', creditcard),
    ('credit_card[month]',"03"),
    ('credit_card[year]',credityear),
    ('credit_card[rvv]',creditsec),
    ('order[terms]' ,'0'),
    ('order[terms]', '1') #delete ]) for captcha, //check box for terms
    ])

    #driver.findElement(By.name("userName")).sendKeys ("tutorial");
    cookies1 = {'_utmc' : _UTMC, '_gat' : _GAT, '__utmt': __UTMT }
    with requests.Session() as response:
        cookie = response.cookies.get_dict()
        {}
        get_data = response.get(atclink, data = d1)
        post_data = response.post(atclink, data=d1, headers = headers1)
        cookies1 = response.cookies

        for c in cookies1:
            if 'cart' in c.name:
                cart = {'name':'cart', 'value': c.value,
                'path': '/'}
            if '_supreme' in c.name:
                sup_sesh = {'name':'_supreme_sess', 'value': c.value,
                'path': '/'}
        print cart
        print sup_sesh
        addy1 = {'name' : 'address',
        'value': addy, 'path':'/'}
        print addy1



        driver = webdriver.Chrome('/Users/'+ username +'/Downloads/chromedriver')
        driver.get("http://www.supremenewyork.com/shop/cart")

        driver.add_cookie(cart)
        driver.add_cookie(addy1)
        driver.add_cookie(sup_sesh)
        # driver.add_cookie({'name' : 'cart' , 'value' : c.value, 'secure' : False})
        # driver.add_cookie({'name' : 'address' , 'value' : addy, 'secure' : False})

        driver.refresh()
        driver.refresh()

        link = driver.find_element_by_css_selector("a[href='https://www.supremenewyork.com/checkout']")
        print 1

        link.click()
        driver.find_element_by_name("credit_card[type]").send_keys(creditcardtype)
        driver.find_element_by_id("cnb").send_keys(creditcard)
        driver.find_element_by_id("credit_card_month").send_keys(creditmonth)
        driver.find_element_by_id("credit_card_year").send_keys(credityear)
        driver.find_element_by_id("vval").send_keys(creditsec)

def quit():
    handler()
    master.destroy()
def handler():
    f = open("backup", "w")
    print var.get().strip()
    f.write(var.get().strip()+ '\n')
    print 123
    f.write(keyword1.get().strip()+ '\n')
    print keyword1.get().strip()
    f.write(colorwave1.get()+'\n')
    print colorwave1.get().strip()
    f.write(var1.get().strip()+'\n')
    f.write(var2.get().strip()+'\n')
    f.write(var3.get().strip()+'\n')
    f.write(fullname1.get()+'\n')
    f.write(email1.get()+'\n')
    f.write(tele1.get()+'\n') #10
    f.write(address2.get()+'\n')
    f.write(SecAddress.get()+'\n')
    f.write(zipcode1.get()+'\n')
    f.write(city1.get()+'\n')
    f.write(state1.get()+'\n')
    f.write(var4.get()+'\n')
    f.write(creditcard.get()+'\n')
    f.write(creditmonth1.get()+'\n')
    f.write(credityear1.get()+'\n')
    f.write(creditsec1.get()+'\n')
    f.close()
    master.quit()


if __name__ == '__main__':
    #copy link from UK version lol we scheming
    try:
        f = open("backup", "r")
        ii=0
        a =""
        b = ""
        c = ""
        d= ""
        e= ""
        z= ""
        g= ""
        h= ""
        i= ""
        j= ""
        k= ""
        l= ""
        m= ""
        n= ""
        o= ""
        p= ""
        q= ""
        r= ""
        s= ""
        t= ""
        # print "what"
        # with open("backup") as fp:
        #     for ii, line in enumerate(fp):
        #         print ii
        #         print line
        #         if ii == 0:
        #             a = line
        #             print a
        #         elif ii == 1:
        #             b = line
        #             print b
        #         elif ii == 2:
        #             c = line
        #             print c
        #         elif ii == 3:
        #             ii += 1
        #             d = line
        #             print d
        #         elif ii == 4:
        #             ii += 1
        #             e = line
        #             print e
        #         elif ii == 5:
        #             ii += 1
        #             z = line
        #             print z
        #         elif ii == 6:
        #             ii += 1
        #             g = line
        #         elif ii == 7:
        #             ii += 1
        #             h = line
        #         elif ii == 8:
        #             ii += 1
        #             i = line
        #         elif ii == 9:
        #             ii += 1
        #             j = line
        #         elif ii == 10:
        #             ii += 1
        #             k = line
        #         elif ii == 11:
        #             ii += 1
        #             l = line
        #         elif ii == 12:
        #             ii += 1
        #             m = line
        #         elif ii == 13:
        #             ii += 1
        #             n = line
        #         elif ii == 14:
        #             ii += 1
        #             o = line
        #         elif ii == 15:
        #             ii += 1
        #             p = line
        #         elif ii == 16:
        #             ii += 1
        #             q = line
        #         elif ii == 17:
        #             ii += 1
        #             r = line
        #         elif ii == 18:
        #             ii += 1
        #             s = line
        #         elif ii == 19:
        #             ii += 1
        #             t = line
        #         elif ii > 19:
        #             break
        #         ii += 1

        a=f.readline().strip()
        print "fuck"
        print a
        b=f.readline().strip()
        print b
        c=f.readline().strip()
        print c
        d=f.readline().strip()
        print d
        e=f.readline().strip()
        print e
        z=f.readline().strip()
        g=f.readline().strip()
        h=f.readline().strip()
        i=f.readline().strip()
        j=f.readline().strip()
        k=f.readline().strip()
        l=f.readline().strip()
        m=f.readline().strip()
        n=f.readline().strip()
        o=f.readline().strip()
        p=f.readline().strip()
        q=f.readline().strip()
        r=f.readline().strip()
        s=f.readline().strip()
        t=f.readline().strip()

        # d=f.readline().splitlines()[0]
        # e=f.readline().splitlines()[0]
        # z=f.readline().splitlines()[0]
        # g=f.readline().splitlines()[0]
        # h=f.readline().splitlines()[0]
        # i=f.readline().splitlines()[0]
        # j=f.readline().splitlines()[0]
        # k=f.readline().splitlines()[0]
        # l=f.readline().splitlines()[0]
        # m=f.readline().splitlines()[0]
        # n=f.readline().splitlines()[0]
        # o=f.readline().splitlines()[0]
        # p=f.readline().splitlines()[0]
        # q=f.readline().splitlines()[0]
        # r=f.readline().splitlines()[0]
        # s=f.readline().splitlines()[0]
        # t=f.readline().splitlines()
        print a,b,c,d,e,g,h,i,j,k,l,m,n,o,p,q,r,s,t


        for name in ('LOGNAME', 'USER', 'LNAME', 'USERNAME'):
            user = os.environ.get(name)
            if user:
                username = (user)

             # If not user from os.environ.get()


        print username
#        category = raw_input("Category?(all lower case please):") #what you want
#        keyword = raw_input("You need a UNIQUE keyword for it to work Properly, something the other items names do not have keyword? (captialize first letter in each word) :")
#        colorwave = raw_input("color? (captialize first letter in each word) :")
#        size = raw_input("size? small -> xlarge:")
        category = ""
        keyword = ""
        colorwave = ""
        size = ""
        fullname= ""
        email = ""
        tele = ""
        address = ""
        address1 = ""
        zipcode = ""
        city = ""
        state = ""
        creditcardtype = ""
        creditcard = ""
        creditmonth = ""
        credityear = ""
        creditsec = ""


        master = tk.Tk()
        mycolor2 = 'red'
        master.geometry("600x320+30+30")
        master.tk_setPalette(background='white', foreground='black',
        activeBackground='white', activeForeground='black')


        # image = Image.open("supreme11.jpg")
        # photo = ImageTk.PhotoImage(image)
        #
        # label = tk.Label(image=photo)
        # label.image = photo # keep a reference!
        # label.grid(row=0, column=0, columnspan=4, rowspan=1,
        #        sticky="W"+'E', padx=0, pady=0)
        #


        master.title("The Giver Bot")
        tk.Label(master, text="Category",font=('comic sans ms', 12), fg ='black').grid(row=1, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Keyword",font=('comic sans ms', 12), fg ='black').grid(row=2, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Colorwave",font=('comic sans ms', 12), fg ='black').grid(row=3, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Top size",font=('comic sans ms', 12), fg ='black').grid(row=4, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Shoe size",font=('comic sans ms', 12), fg ='black').grid(row=5, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Pants size",font=('comic sans ms', 12), fg ='black').grid(row=6, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Full name",font=('comic sans ms', 12), fg ='black').grid(row=7, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Email",font=('comic sans ms', 12), fg ='black').grid(row=8, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Tele",font=('comic sans ms', 12), fg ='black').grid(row=9, column = 0, sticky = 'w'+ 'n')
        tk.Label(master, text="Address",font=('comic sans ms', 12), fg ='black').grid(row=1, column = 3, sticky = 'w'+ 'n')
        tk.Label(master, text="Address1",font=('comic sans ms', 12), fg ='black').grid(row=2,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Zipcode",font=('comic sans ms', 12), fg ='black').grid(row=3,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="City",font=('comic sans ms', 12), fg ='black').grid(row=4,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="State",font=('comic sans ms', 12), fg ='black').grid(row=5,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Credit card type ",font=('comic sans ms', 12), fg ='black').grid(row=6,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Credit card num",font=('comic sans ms', 12), fg ='black').grid(row=7,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Credit month",font=('comic sans ms', 12), fg ='black').grid(row=8,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Credit year",font=('comic sans ms', 12), fg ='black').grid(row=9,column=3, sticky = 'w'+ 'n')
        tk.Label(master, text="Credit SEC",font=('comic sans ms', 12), fg ='black').grid(row=10,column=3, sticky = 'w'+ 'n')


        # category1 = tk.Listbox(master)
        # category1.pack()
        #
        # for item in ["jackets", "shirts", "tshirts", "sweaters", "sweatshirts", "pants", "shorts", "hats", "accessories", "shoes"]:
        #     category1.insert("end", item)

        var = tk.StringVar(master, value=a)
        category1 =tk.OptionMenu(master, var,"jackets", "shirts", "tshirts", "sweaters", "sweatshirts", "pants", "shorts", "hats", "accessories", "shoes")
        category1.config(width=20, bg = 'white')
        category1.grid(row=1, column=2)


        kw1 = tk.StringVar(master, value=b)
        keyword1 = tk.Entry(master, textvariable=kw1,fg ='black')

        cw1 = tk.StringVar(master, value=c)
        colorwave1 = tk.Entry(master, textvariable=cw1,fg ='black')



        var1 = tk.StringVar(master, value=d)
        size1 =tk.OptionMenu(master, var1,'','Small', 'Medium', 'Large', 'XLarge')
        size1.config(width=20)
        size1.grid(row=3, column=1)

        var2 = tk.StringVar(master, value=e)
        shoesize =tk.OptionMenu(master, var2,'','6', '7', '8', '9','10', '11', '12', '13')
        shoesize.config(width=20)
        shoesize.grid(row=4, column=1)

        var3 = tk.StringVar(master, value=z)
        pantssize =tk.OptionMenu(master, var3, '', '28', '29', '30', '31','32', '33', '34', '35', '36')
        pantssize.config(width=20)
        pantssize.grid(row=5, column=1)


        fn1 = tk.StringVar(master, value=g)
        fullname1 = tk.Entry(master, textvariable=fn1, fg ='black')

        em = tk.StringVar(master, value=h)
        email1 = tk.Entry(master, textvariable=em,fg ='black')

        tele = tk.StringVar(master, value=i)
        tele1 = tk.Entry(master, textvariable=tele,fg ='black')

        ad = tk.StringVar(master, value=j)
        address2 = tk.Entry(master, textvariable=ad,fg ='black')

        ad1 = tk.StringVar(master, value=k)
        SecAddress = tk.Entry(master, textvariable=ad1,fg ='black')

        zipcode = tk.StringVar(master, value=l)
        zipcode1 = tk.Entry(master, textvariable=zipcode,fg ='black')

        city = tk.StringVar(master, value=m)
        city1 = tk.Entry(master, textvariable = city,fg ='black')

        state = tk.StringVar(master, value=n)
        state1 = tk.Entry(master, textvariable = state,fg ='black')

        var4 = tk.StringVar(master, value=o)
        creditcardtype3 =tk.OptionMenu(master, var4,'visa', 'american_express', 'mastercard')
        creditcardtype3.config(width=20)

        creditcard = tk.StringVar(master, value=p)
        creditcard1 = tk.Entry(master, textvariable = creditcard,fg ='black')

        creditmonth = tk.StringVar(master, value=q)
        creditmonth1 = tk.Entry(master, textvariable = creditmonth,fg ='black')

        credityear = tk.StringVar(master, value=r)
        credityear1 = tk.Entry(master, textvariable = credityear,fg ='black')

        creditsec = tk.StringVar(master, value=s)
        creditsec1 = tk.Entry(master, textvariable = creditsec,fg ='black')

        end = tk.Button(master, text="Cop", command=cop)
        end.grid(row=10,column=0, sticky = 'w'+'n'+'e')

        category1.grid(row=1, column=1)
        keyword1.grid(row=2, column=1)
        colorwave1.grid(row=3, column=1)
        size1.grid(row=4, column=1)
        shoesize.grid(row=5, column=1)
        pantssize.grid(row=6, column=1)
        fullname1.grid(row=7, column=1)
        email1.grid(row=8, column=1)
        tele1.grid(row=9, column=1)
        address2.grid(row=1, column=4)
        SecAddress.grid(row=2, column=4)
        zipcode1.grid(row=3, column=4)
        city1.grid(row=4, column=4)
        state1.grid(row=5, column=4)
        creditcardtype3.grid(row=6, column=4)
        creditcard1.grid(row=7, column=4)
        creditmonth1.grid(row=8, column=4)
        credityear1.grid(row=9, column=4)
        creditsec1.grid(row=10, column=4)
        end.grid(row=10, column = 1)

        endbutton = tk.Button(master, text = 'Quit', command=handler)
        endbutton.grid(row=11 ,column = 3,sticky = 'w'+'n'+'e')

        endbutton = tk.Button(master, text = 'Quit', command=handler)
        endbutton.grid(row=11 ,column = 3,sticky = 'w'+'n'+'e')

        master.protocol("WM_DELETE_WINDOW", handler)



        # end = tk.Button(master, text="Close", command=master.quit)
        # end.grid(row=11,column=3, sticky = 'w'+'n'+'e')

        master.mainloop()






    except Exception as e:
        if hasattr(e, 'message'):
            print(e.message)
        else:
            print(e)
          #you need this to throw the exception
